package question3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
/***
 * The following code defines MapReduce driver, mapper and reducer class for
 * finding out top ten hottest and coldest days using Hashtable and ArrayList datastructures.
 * @author Hemant
 */
public class HotAndColdDriver {
	public static class  HotAndColdMapper extends Mapper<LongWritable, Text, Text, Text> {
		public static final int limit = 9999;
		private ArrayList<Float> maxTempList = new ArrayList<Float> ();
		private ArrayList<Float> minTempList = new ArrayList<Float> ();
		public Hashtable<Float,String> maxTempDateTable = new Hashtable<Float,String>();
		public Hashtable<Float,String> minTempDateTable = new Hashtable<Float,String>();
		public void map(LongWritable arg0, Text Value, Context context) throws IOException, InterruptedException {

			//Converting the record  to String and storing it in a String variable 
			String currentRecord = Value.toString();

			//Checking if the line is not empty
			if (!(currentRecord.length() == 0)) {

				//date

				String date = currentRecord.substring(6, 14);

				//maximum temperature

				float temp_Max = Float
						.parseFloat(currentRecord.substring(39, 45).trim());

				//minimum temperature

				float temp_Min = Float
						.parseFloat(currentRecord.substring(47, 53).trim());

				if (temp_Max!=limit&&temp_Min!=limit){
					maxTempDateTable.put(temp_Max,date);
					minTempDateTable.put(temp_Min,date);
					maxTempList.add(temp_Max);
					minTempList.add(temp_Min);
				}

			}
		}
		@Override
		protected void cleanup(Mapper<LongWritable, Text, Text, Text>.Context context)throws IOException, InterruptedException {
		Collections.sort(maxTempList); Collections.sort(minTempList);
		for (int i = 0; i<10; i++) {
			float minTemperature = minTempList.get(i);
			context.write(new Text("Coldest Day: "+minTempDateTable.get(minTemperature)), new Text(String.valueOf(minTemperature)));
		}
		for (int j=maxTempList.size()-1;j>maxTempList.size()-11;j--) {
			float maxTemperature = maxTempList.get(j);
			context.write(new Text("Hottest Day: "+maxTempDateTable.get(maxTemperature)),new Text(String.valueOf(maxTemperature)));
		}
	}
	}

	public static class HotAndColdReducer extends Reducer<Text, Text, Text, Text> {
		public void reduce(Text Key, Iterator<Text> Values, Context context) throws IOException, InterruptedException {
			//putting all the values in temperature variable of type String
			String temperature = Values.next().toString();
			context.write(Key, new Text(temperature));
		}

	}

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = new Job(conf, "10 Top Hottest and Coldest Days");
		job.setJarByClass(HotAndColdDriver.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		job.setMapperClass(HotAndColdDriver.HotAndColdMapper.class);
		job.setReducerClass(HotAndColdDriver.HotAndColdReducer.class);
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		Path OutputPath = new Path(args[1]);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		OutputPath.getFileSystem(conf).delete(OutputPath);
		System.exit(job.waitForCompletion(true) ? 0 : 1);

	}
}
	