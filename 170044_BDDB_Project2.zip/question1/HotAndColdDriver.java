package question1;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
/***
 * The following code defines MapReduce driver, mapper and reducer class
 * for calculating the highest temperature of each year using Hashtable Data Structure.
 * @author Hemant
 *
 */
public class HotAndColdDriver {

	public static class  HotAndColdMapper extends Mapper<LongWritable, Text, Text, Text> {
	
		public static final int limit = 9999;
		Hashtable<String, Float> year_temp_pairs = new Hashtable<String, Float>();
		public void map(LongWritable arg0, Text Value, Context context) throws IOException, InterruptedException {

			//Converting the record  to String and storing it in a String variable 
			String currentRecord = Value.toString();

			//Checking if the line is not empty
			if (!(currentRecord.length() == 0)) {

				//date_year

				String year = currentRecord.substring(6, 10);

				//maximum temperature

				float temp_Max = Float.parseFloat(currentRecord.substring(39, 45).trim());
				if (!year_temp_pairs.containsKey(year)) if (temp_Max != limit) year_temp_pairs.put(year, temp_Max);
				else if (temp_Max!=limit) {
					float lastSavedTemperature = year_temp_pairs.get(year);
					if (temp_Max>lastSavedTemperature) year_temp_pairs.put(year, temp_Max);
				}
				
			}

		}
@Override
protected void cleanup(
		Mapper<LongWritable, Text, Text, Text>.Context context)
		throws IOException, InterruptedException {
	Set<String> theKeySet = year_temp_pairs.keySet();
	for (String key: theKeySet) {
		context.write(new Text("Hottest Temperature of  " + key),
				new Text(String.valueOf(year_temp_pairs.get(key))));
	}

}
	}

	public static class HotAndColdReducer extends Reducer<Text, Text, Text, Text> {
		public void reduce(Text Key, Iterator<Text> Values, Context context) throws IOException, InterruptedException {
			String temperature = Values.next().toString();
			context.write(Key, new Text(temperature));
		}

	}

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = new Job(conf, "Highest Temperature of Year");
		job.setJarByClass(HotAndColdDriver.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		job.setMapperClass(HotAndColdDriver.HotAndColdMapper.class);
		job.setReducerClass(HotAndColdDriver.HotAndColdReducer.class);
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		Path OutputPath = new Path(args[1]);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		OutputPath.getFileSystem(conf).delete(OutputPath);
		System.exit(job.waitForCompletion(true) ? 0 : 1);

	}
}