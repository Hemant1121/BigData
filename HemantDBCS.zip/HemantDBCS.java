import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class HemantDBCS extends Application{

	Button  bt,submit;
	TextField tf;
    public static void main1(String[] args) throws SQLException {
        // declare a connection by using Connection interface 
        Connection connection = null;
        /* Create string of connection url within specified format with machine 
           name, port number and database name. Here machine name id localhost 
           and database name. */
        String connectionURL = "jdbc:mysql://localhost:3306/file_uploads";
        /*declare a resultSet that works as a table resulted by execute a specified 
           sql query. */
        ResultSet rs = null;
        // Declare prepare statement.
        PreparedStatement psmnt = null;
        // declare FileInputStream object to store binary stream of given image.
        FileInputStream fis;
        try {
            // Load JDBC driver "com.mysql.jdbc.Driver"
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            /* Create a connection by using getConnection() method that takes 
               parameters of string type connection url, user name and password to 
               connect to database. */
            connection = DriverManager.getConnection(connectionURL, "root", "9844hemant");
            
            // create a file object for image by specifying full path of image as parameter.
            File image = new File("F:\\FinalNSs.pdf");
            /* prepareStatement() is used for create statement object that is 
               used for sending sql statements to the specified database. */
            psmnt = connection.prepareStatement("insert into save_files(REG_NO, Roll_NO, Name, Father_Name,Mother_Name,Course,Semester,Year) "+ "values(?,?,?,?)");
            psmnt.setString(1,"1717044");
            psmnt.setString(2,"170044");
            psmnt.setString(3,"Hemant");
            psmnt.setString(4,"Raj");
            psmnt.setString(5,"Jibchhi");
            psmnt.setString(6,"Math");
            psmnt.setString(7,"Second");
        
           
            
            fis = new FileInputStream(image);
            psmnt.setBinaryStream(3, (InputStream)fis, (int)(image.length()));
            /* executeUpdate() method execute specified sql query. Here this query 
               insert data and image from specified address. */
            int s = psmnt.executeUpdate();
            if(s>0) {
                System.out.println("Uploaded successfully !");
            }
            else {
                System.out.println("unsucessfull to upload image.");
            }
        }
        // catch if found any exception during rum time.
        catch (Exception ex) {
            System.out.println("Found some error : "+ex);
        }
        finally {
            // close all the connections.
            connection.close();
            psmnt.close();
        }
    }

	@Override
	public void start(Stage arg0) throws Exception {
		Stage st = new Stage();
		Pane pn = new Pane();
		Scene sc = new Scene(pn, 500,500);


bt = new Button("Upload File!");
bt.setOnAction(e ->{
	System.out.println("Uploaded successfully !");
	Stage stage = new Stage();
	Pane pane = new Pane();
	Scene scene = new Scene(pane,200,200);

	tf.setLayoutX(0);tf.setLayoutY(50);
	submit = new Button("Submit");
	submit.setLayoutX(50);submit.setLayoutY(90);

pane.getChildren().addAll(tf,submit);

stage.setTitle("DBCS");
stage.setScene(scene);
stage.show();
});
tf = new TextField();

Label lb = new Label("RegNo");
lb.setLayoutX(10);lb.setLayoutY(50);
Label lb1 = new Label("Roll_No");
lb.setLayoutX(100);lb.setLayoutY(150);
Label lb2 = new Label("Name");
lb.setLayoutX(200);lb.setLayoutY(250);
Label lb3 = new Label("Father Name");
lb.setLayoutX(300);lb.setLayoutY(350);
Label lb4 = new Label("Mother Name");
lb.setLayoutX(400);lb.setLayoutY(450);
Label lb5 = new Label("Course");
lb.setLayoutX(500);lb.setLayoutY(550);
Label lb6 = new Label("Semester");
lb.setLayoutX(600);lb.setLayoutY(650);
Label lb7 = new Label("Year");

TextField tb1 = new TextField();
tb1.setLayoutX(100);
TextField tb2 = new TextField();
tb2.setLayoutX(200);
TextField tb3 = new TextField();
TextField tb4 = new TextField();
TextField tb5 = new TextField();
TextField tb6 = new TextField();
TextField tb7 = new TextField();
TextField tb8 = new TextField();

pn.getChildren().addAll(bt,lb,lb1,lb2,lb3,lb4,lb5,lb6,lb7,tb1,tb2,tb3,tb4,tb5,tb6,tb7,tb8);
st.setTitle("DBCS");
st.setScene(sc);
st.show();
	}
	public static void main (String[]args) {
		Application.launch();
	}

}
